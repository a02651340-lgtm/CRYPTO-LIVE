import { NewsArticle } from '../types';

export const FALLBACK_NEWS_ARTICLES: NewsArticle[] = [
  {
    id: '1',
    title: 'Bitcoin Surges Past Key Resistance Levels as Institutional Inflows Hit Record Highs',
    body: 'Decentralized financial networks experience significant capitalization spikes as major global ETF providers report sustained positive inflows across high volume liquidity pools.',
    url: 'https://cointelegraph.com',
    imageurl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=1200&q=80',
    source: 'COINTELEGRAPH',
    published_on: Math.floor(Date.now() / 1000) - 300,
  },
  {
    id: '2',
    title: 'Ethereum Layer-2 Networks Process Record Daily Transaction Throughput',
    body: 'Scalability improvements across optimistic and zero-knowledge rollup infrastructure result in historic gas efficiency and micro-transaction volume.',
    url: 'https://coindesk.com',
    source: 'COINDESK',
    published_on: Math.floor(Date.now() / 1000) - 1200,
  },
  {
    id: '3',
    title: 'Global Regulatory Standardizations Focus on Proof-of-Reserve Protocol Transparency',
    body: 'International banking authorities introduce unified verification frameworks for centralized exchanges and algorithmic stablecoin collaterals.',
    url: 'https://cointelegraph.com',
    source: 'COINTELEGRAPH',
    published_on: Math.floor(Date.now() / 1000) - 2400,
  },
  {
    id: '4',
    title: 'Solana Ecosystem Expands Liquid Staking Protocols and Yield Aggregators',
    body: 'DeFi capital deployment across high-performance smart contract architectures reaches new multi-year highs amidst low transaction latency.',
    url: 'https://decrypt.co',
    source: 'DECRYPT',
    published_on: Math.floor(Date.now() / 1000) - 3600,
  },
  {
    id: '5',
    title: 'Cross-Chain Interoperability Bridges Implement Quantum-Resistant Cryptography',
    body: 'Next-generation relay bridges upgrade security parameters to withstand post-quantum computing attacks across cross-chain messaging layers.',
    url: 'https://blockworks.co',
    source: 'BLOCKWORKS',
    published_on: Math.floor(Date.now() / 1000) - 4800,
  },
  {
    id: '6',
    title: 'Binance Protocol Upgrade Accelerates On-Chain Settlement Verification Speed',
    body: 'Binance ecosystem releases mainnet maintenance update improving block propagation times and peer-to-peer node sync speed globally.',
    url: 'https://binance.com',
    source: 'BINANCE DISPATCH',
    published_on: Math.floor(Date.now() / 1000) - 6000,
  },
  {
    id: '7',
    title: 'DeFi Autonomous Vaults Exceed $45 Billion total Value Locked across EVM Chains',
    body: 'Yield optimization protocols report surge in stablecoin deposits following new decentralized insurance parameters.',
    url: 'https://coindesk.com',
    source: 'DEFI PULSE',
    published_on: Math.floor(Date.now() / 1000) - 7200,
  },
  {
    id: '8',
    title: 'Institutional Custody Standards Mandate Multi-Party Computation (MPC) Signatures',
    body: 'Tier-1 digital asset custodians adopt hardware-enforced threshold signature schemes for corporate treasury protection.',
    url: 'https://cointelegraph.com',
    source: 'COINTELEGRAPH',
    published_on: Math.floor(Date.now() / 1000) - 8400,
  },
  {
    id: '9',
    title: 'Zero-Knowledge Cryptography Framework Enables Privacy-Preserving Compliance',
    body: 'ZK-SNARK primitives allow financial institutions to verify KYC metrics without disclosing private wallet ownership data.',
    url: 'https://blockworks.co',
    source: 'BLOCKWORKS',
    published_on: Math.floor(Date.now() / 1000) - 9600,
  },
  {
    id: '10',
    title: 'Avalanche Subnets Deploy Custom Gas Tokens for Sovereign Enterprise Applications',
    body: 'Corporate developers deploy dedicated subnet chains with custom transaction rules and gas fee tokenomics.',
    url: 'https://decrypt.co',
    source: 'DECRYPT',
    published_on: Math.floor(Date.now() / 1000) - 10800,
  },
  {
    id: '11',
    title: 'Ripple On-Demand Liquidity Expands Cross-Border Payment Corridors in LATAM',
    body: 'XRP ledger settlement rails onboard major regional banking partners for real-time remittance clearing.',
    url: 'https://coindesk.com',
    source: 'COINDESK',
    published_on: Math.floor(Date.now() / 1000) - 12000,
  },
  {
    id: '12',
    title: 'Cardano Hydra Scaling Solution Demonstrates High TPS in Peer-to-Peer Benchmarks',
    body: 'Hydra head micro-payment channels achieve ultra-low latency transaction clearing in stress-test network conditions.',
    url: 'https://cointelegraph.com',
    source: 'COINTELEGRAPH',
    published_on: Math.floor(Date.now() / 1000) - 13200,
  },
];

export async function fetchLiveNewsFeed(): Promise<NewsArticle[]> {
  try {
    const rssUrls = [
      'https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fcointelegraph.com%2Frss',
      'https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fcoindesk.com%2Farc%2Foutboundfeeds%2Frss%2F',
    ];

    const results = await Promise.allSettled(
      rssUrls.map((url) => fetch(url).then((res) => res.json()))
    );

    const fetchedArticles: NewsArticle[] = [];

    results.forEach((res, idx) => {
      if (res.status === 'fulfilled' && res.value && res.value.status === 'ok') {
        const feedSource = idx === 0 ? 'COINTELEGRAPH' : 'COINDESK';
        const items = res.value.items || [];
        items.forEach((item: any, i: number) => {
          const title = item.title ? item.title.trim() : '';
          if (!title) return;

          // clean snippet or description
          let body = item.description || item.content || '';
          body = body.replace(/<[^>]+>/g, '').trim();
          if (body.length > 220) body = body.substring(0, 220) + '...';

          const publishedOn = item.pubDate
            ? Math.floor(new Date(item.pubDate).getTime() / 1000)
            : Math.floor(Date.now() / 1000) - i * 300;

          fetchedArticles.push({
            id: `rss-${idx}-${i}-${Date.now()}`,
            title,
            body: body || 'Live market dispatch from protocol newsfeed.',
            url: item.link || item.guid || 'https://cointelegraph.com',
            imageurl: item.thumbnail || item.enclosure?.link,
            source: feedSource,
            published_on: publishedOn,
          });
        });
      }
    });

    if (fetchedArticles.length > 0) {
      // sort by published_on desc
      fetchedArticles.sort((a, b) => b.published_on - a.published_on);
      return fetchedArticles;
    }
  } catch (err) {
    console.warn('RSS feed fetch error, returning fallback news:', err);
  }

  return FALLBACK_NEWS_ARTICLES;
}
