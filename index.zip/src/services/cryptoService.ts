import { CryptoTicker } from '../types';

const SYMBOL_MAPPING: Record<string, string> = {
  BTCUSD: 'BTCUSDT',
  ETHUSD: 'ETHUSDT',
  BNBUSD: 'BNBUSDT',
  SOLUSD: 'SOLUSDT',
  ADAUSD: 'ADAUSDT',
  XRPUSD: 'XRPUSDT',
  DOTUSD: 'DOTUSDT',
  DOGEUSD: 'DOGEUSDT',
  LINKUSD: 'LINKUSDT',
  AVAXUSD: 'AVAXUSDT',
  BTCUSDT: 'BTCUSDT',
  ETHUSDT: 'ETHUSDT',
  BNBUSDT: 'BNBUSDT',
  SOLUSDT: 'SOLUSDT',
  ADAUSDT: 'ADAUSDT',
  XRPUSDT: 'XRPUSDT',
  DOTUSDT: 'DOTUSDT',
  DOGEUSDT: 'DOGEUSDT',
  LINKUSDT: 'LINKUSDT',
  AVAXUSDT: 'AVAXUSDT',
};

const COINGECKO_MAP: Record<string, string> = {
  bitcoin: 'BTCUSDT',
  ethereum: 'ETHUSDT',
  binancecoin: 'BNBUSDT',
  solana: 'SOLUSDT',
  cardano: 'ADAUSDT',
  ripple: 'XRPUSDT',
  polkadot: 'DOTUSDT',
  dogecoin: 'DOGEUSDT',
  chainlink: 'LINKUSDT',
  'avalanche-2': 'AVAXUSDT',
};

export async function fetchLiveCryptoPrices(): Promise<CryptoTicker[]> {
  // Strategy 1: Binance US API (unrestricted, ultra-fast 24hr ticker)
  try {
    const binanceUsSymbols = [
      'BTCUSD',
      'ETHUSD',
      'BNBUSD',
      'SOLUSD',
      'ADAUSD',
      'XRPUSD',
      'DOGEUSD',
      'LINKUSD',
      'AVAXUSD',
    ];
    const url = `https://api.binance.us/api/v3/ticker/24hr?symbols=${encodeURIComponent(
      JSON.stringify(binanceUsSymbols)
    )}`;
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        return data.map((item: any) => ({
          symbol: SYMBOL_MAPPING[item.symbol] || item.symbol,
          lastPrice: item.lastPrice,
          priceChangePercent: item.priceChangePercent,
        }));
      }
    }
  } catch (err) {
    console.warn('Binance US API query failed, falling back to CoinGecko:', err);
  }

  // Strategy 2: CoinGecko Simple Price API
  try {
    const cgUrl =
      'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,binancecoin,solana,cardano,ripple,polkadot,dogecoin,chainlink,avalanche-2&vs_currencies=usd&include_24hr_change=true';
    const response = await fetch(cgUrl);
    if (response.ok) {
      const data = await response.json();
      const results: CryptoTicker[] = [];
      for (const [cgId, sym] of Object.entries(COINGECKO_MAP)) {
        if (data[cgId]) {
          results.push({
            symbol: sym,
            lastPrice: data[cgId].usd.toString(),
            priceChangePercent: (data[cgId].usd_24h_change || 0).toString(),
          });
        }
      }
      if (results.length > 0) return results;
    }
  } catch (err) {
    console.warn('CoinGecko fallback failed:', err);
  }

  // Strategy 3: Global Binance API (as a final backup)
  try {
    const globalUrl = 'https://api.binance.com/api/v3/ticker/24hr';
    const response = await fetch(globalUrl);
    if (response.ok) {
      const data = await response.json();
      const targets = [
        'BTCUSDT',
        'ETHUSDT',
        'BNBUSDT',
        'SOLUSDT',
        'ADAUSDT',
        'XRPUSDT',
        'DOTUSDT',
        'DOGEUSDT',
        'LINKUSDT',
        'AVAXUSDT',
      ];
      if (Array.isArray(data)) {
        return data
          .filter((item: any) => targets.includes(item.symbol))
          .map((item: any) => ({
            symbol: item.symbol,
            lastPrice: item.lastPrice,
            priceChangePercent: item.priceChangePercent,
          }));
      }
    }
  } catch (err) {
    console.warn('Global Binance fallback failed:', err);
  }

  return [];
}
