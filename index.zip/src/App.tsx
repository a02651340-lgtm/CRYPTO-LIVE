import React, { useEffect, useState, useCallback } from 'react';
import { NewsArticle, ToastMessage } from './types';
import { fetchLiveNewsFeed, FALLBACK_NEWS_ARTICLES } from './services/newsService';
import { IntroOverlay } from './components/IntroOverlay';
import { Header } from './components/Header';
import { NavDrawer } from './components/NavDrawer';
import { LiveTicker } from './components/LiveTicker';
import { HeadlineCard } from './components/HeadlineCard';
import { NewsExplorer } from './components/NewsExplorer';
import { MarketInsights } from './components/MarketInsights';
import { PressReleases } from './components/PressReleases';
import { MarketStats } from './components/MarketStats';
import { CryptoConverter } from './components/CryptoConverter';
import { CyberTraderWidget } from './components/CyberTraderWidget';
import { SubscribeModal } from './components/SubscribeModal';
import { ToastContainer } from './components/ToastContainer';
import { Globe, Radio, Shield, Zap, Flame, ExternalLink } from 'lucide-react';

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSubscribeModalOpen, setIsSubscribeModalOpen] = useState(false);
  const [liveStatus, setLiveStatus] = useState<'online' | 'connecting' | 'error'>('online');
  const [news, setNews] = useState<NewsArticle[]>(FALLBACK_NEWS_ARTICLES);
  const [loadingNews, setLoadingNews] = useState(false);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((text: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const fetchNewsFeed = async () => {
    setLoadingNews(true);
    try {
      const articles = await fetchLiveNewsFeed();
      if (articles && articles.length > 0) {
        setNews(articles);
      }
    } catch (err) {
      console.warn('News fetch notice:', err);
    } finally {
      setLoadingNews(false);
    }
  };

  useEffect(() => {
    fetchNewsFeed();
    const interval = setInterval(fetchNewsFeed, 120000);
    return () => clearInterval(interval);
  }, []);

  const handleSubscribeSuccess = (subscriberName: string) => {
    addToast(`Telemetric profile established! Welcome, ${subscriberName}.`, 'success');
  };

  return (
    <div className="min-h-screen bg-[#060913] text-white flex flex-col relative font-rajdhani selection:bg-[#00ffcc] selection:text-black">
      {/* 1. Intro Animation Overlay */}
      {showIntro && <IntroOverlay onComplete={() => setShowIntro(false)} />}

      {/* 2. Top Header Bar */}
      <Header
        isMenuOpen={isMenuOpen}
        toggleMenu={() => setIsMenuOpen(!isMenuOpen)}
        openSubscribeModal={() => setIsSubscribeModalOpen(true)}
        liveStatus={liveStatus}
      />

      {/* 3. Slide-out Navigation Drawer */}
      <NavDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        openSubscribeModal={() => setIsSubscribeModalOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* 4. Live Binance Price Ticker Marquee */}
      <LiveTicker setLiveStatus={setLiveStatus} />

      {/* 5. Main Dashboard Bento Grid Layout */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="text-indigo-400 font-mono text-xs uppercase tracking-widest">Autonomous Data Matrix</span>
            <h2 className="font-orbitron font-bold text-2xl sm:text-3xl text-white uppercase tracking-tight flex items-center gap-3">
              <span>Crypto Intelligence</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-cyan-400 to-[#00ffcc]">Grid</span>
            </h2>
          </div>
          <button
            onClick={() => {
              fetchNewsFeed();
              addToast('Refreshing news telemetry...', 'info');
            }}
            className="text-xs font-mono font-semibold text-white hover:text-indigo-300 flex items-center gap-2 px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 rounded-full cursor-pointer transition-all shadow-md shadow-indigo-500/10"
          >
            <Zap size={14} className="text-indigo-400" />
            <span>Sync Feed</span>
          </button>
        </div>

        {/* Bento Grid 12-column system */}
        <div className="grid grid-cols-12 gap-6 items-stretch">
          {/* Bento Card 1: Top Headline (Col Span 8) */}
          <div className="col-span-12 lg:col-span-8 flex flex-col">
            <HeadlineCard articles={news} loading={loadingNews} />
          </div>

          {/* Bento Card 2: Market Insights / Core Assets (Col Span 4) */}
          <div className="col-span-12 lg:col-span-4 flex flex-col">
            <MarketInsights openSubscribeModal={() => setIsSubscribeModalOpen(true)} />
          </div>

          {/* Bento Card 3: News Explorer Table (Col Span 8) */}
          <div className="col-span-12 lg:col-span-8 flex flex-col">
            <NewsExplorer articles={news} loading={loadingNews} />
          </div>

          {/* Right Column Stack: Converter, Press Releases & Market Statistics (Col Span 4) */}
          <div className="col-span-12 lg:col-span-4 flex flex-col gap-6">
            <CryptoConverter />
            <PressReleases articles={news} loading={loadingNews} />
            <MarketStats />
          </div>
        </div>
      </main>

      {/* 6. Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-8 px-4 sm:px-8 mt-12 text-center text-slate-500 font-mono text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white tracking-tight text-base font-orbitron">
              CRYPTO<span className="text-indigo-400">LIVE</span>
            </span>
            <span className="text-slate-700">|</span>
            <span className="text-slate-400">REAL-TIME MARKET CYBERNETICS</span>
          </div>

          <p className="text-slate-500">
            © {new Date().getFullYear()} CRYPTO LIVE INC. ALL SYSTEM SERVICES OPERATIONAL.
          </p>

          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setIsSubscribeModalOpen(true)} className="hover:text-indigo-400 transition-colors">
              API TELEMETRY
            </button>
            <span>•</span>
            <button onClick={() => setIsSubscribeModalOpen(true)} className="hover:text-indigo-400 transition-colors">
              ALERTS
            </button>
          </div>
        </div>
      </footer>

      {/* 7. Floating Cyber Trader Character */}
      <CyberTraderWidget openSubscribeModal={() => setIsSubscribeModalOpen(true)} />

      {/* 8. Subscriber Modal */}
      <SubscribeModal
        isOpen={isSubscribeModalOpen}
        onClose={() => setIsSubscribeModalOpen(false)}
        onSuccess={handleSubscribeSuccess}
      />

      {/* 9. Floating Toast Alerts */}
      <ToastContainer toasts={toasts} />
    </div>
  );
}
