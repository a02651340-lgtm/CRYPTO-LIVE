export interface CryptoTicker {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  body: string;
  url: string;
  imageurl?: string;
  source: string;
  published_on: number;
  categories?: string;
}

export interface MarketStat {
  label: string;
  value: string;
  change?: string;
  highlight?: boolean;
}

export interface SubscriberFormData {
  fullName: string;
  age: string;
  phone: string;
  email: string;
  experience: string;
}

export interface ToastMessage {
  id: string;
  text: string;
  type: 'success' | 'info' | 'error';
}
