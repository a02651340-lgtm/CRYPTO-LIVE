import React, { useState, useEffect, useRef } from 'react';
import { NewsArticle } from '../types';
import { ExternalLink, Clock, Flame, ArrowUpRight, ChevronLeft, ChevronRight, Pause, Play, Zap } from 'lucide-react';

interface HeadlineCardProps {
  articles: NewsArticle[];
  loading: boolean;
}

export const HeadlineCard: React.FC<HeadlineCardProps> = ({ articles, loading }) => {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  // Auto-advance speed in milliseconds (3000ms = 3s speed, fast & dynamic)
  const [intervalMs, setIntervalMs] = useState(3000);
  const [progress, setProgress] = useState(0);

  // Filter top 6 articles for headline rotation
  const headlineArticles = articles.slice(0, 6);

  // Reset index if articles change and current is out of bounds
  useEffect(() => {
    if (currentIndex >= headlineArticles.length && headlineArticles.length > 0) {
      setCurrentIndex(0);
    }
  }, [headlineArticles.length, currentIndex]);

  // Timer for smooth progress bar and auto-slide
  useEffect(() => {
    if (loading || headlineArticles.length <= 1 || isPaused) {
      setProgress(0);
      return;
    }

    const stepMs = 50;
    const progressTimer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + (stepMs / intervalMs) * 100;
        if (next >= 100) {
          setCurrentIndex((current) => (current + 1) % headlineArticles.length);
          return 0;
        }
        return next;
      });
    }, stepMs);

    return () => clearInterval(progressTimer);
  }, [loading, headlineArticles.length, isPaused, intervalMs]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % headlineArticles.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + headlineArticles.length) % headlineArticles.length);
    setProgress(0);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const xc = rect.width / 2;
    const yc = rect.height / 2;
    const tiltX = -((y - yc) / yc) * 2;
    const tiltY = ((x - xc) / xc) * 2;
    setTilt({ x: tiltX, y: tiltY });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setIsPaused(false);
  };

  if (loading || headlineArticles.length === 0) {
    return (
      <div className="w-full min-h-[380px] bg-slate-900 border border-slate-800 rounded-3xl p-8 flex flex-col justify-end animate-pulse">
        <div className="h-6 w-32 bg-slate-800 rounded mb-4" />
        <div className="h-8 w-3/4 bg-slate-800 rounded mb-3" />
        <div className="h-4 w-1/2 bg-slate-800 rounded mb-6" />
        <div className="h-4 w-1/4 bg-slate-800 rounded" />
      </div>
    );
  }

  const currentArticle = headlineArticles[currentIndex] || headlineArticles[0];

  const pubDate = new Date(currentArticle.published_on * 1000).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  const bgImage = currentArticle.imageurl || 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=1200&q=80';

  return (
    <div
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
        backgroundImage: `linear-gradient(180deg, rgba(15, 23, 42, 0.35) 0%, rgba(2, 6, 23, 0.96) 82%), url('${bgImage}')`,
      }}
      className="relative min-h-[400px] bg-cover bg-center rounded-3xl border border-slate-800 p-6 sm:p-9 flex flex-col justify-between transition-all duration-300 ease-out shadow-2xl group hover:border-indigo-500/60 h-full overflow-hidden select-none"
    >
      {/* Top Animated Progress Bar for Auto-rotation */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-slate-800/80 overflow-hidden z-20">
        <div
          className="h-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-[#00ffcc] transition-all duration-75"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Background Radial Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/20 blur-[100px] rounded-full -mr-20 -mt-20 pointer-events-none" />

      {/* Top Header Control Badges */}
      <div className="flex flex-wrap items-center justify-between gap-2 z-10">
        <div className="flex items-center gap-2">
          <span className="text-indigo-400 font-mono text-[11px] uppercase tracking-widest bg-slate-900/90 px-3 py-1 rounded-full border border-indigo-500/30 flex items-center gap-1.5 backdrop-blur-md shadow-md">
            <Flame size={13} className="text-amber-400 animate-pulse" />
            <span>Headline Feed</span>
            <span className="text-cyan-300 font-bold ml-1">
              {currentIndex + 1}/{headlineArticles.length}
            </span>
          </span>

          {/* Speed Toggle Badge */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              // Cycle speed: 2s -> 3s -> 4s
              setIntervalMs((prev) => (prev === 3000 ? 2000 : prev === 2000 ? 4000 : 3000));
              setProgress(0);
            }}
            className="text-[10px] font-mono font-bold bg-slate-900/90 hover:bg-indigo-950 text-indigo-300 hover:text-white px-2.5 py-1 rounded-full border border-indigo-500/40 backdrop-blur-md transition-all flex items-center gap-1 cursor-pointer"
            title="Click to toggle auto-rotation speed (2s, 3s, 4s)"
          >
            <Zap size={11} className="text-amber-400" />
            <span>{intervalMs / 1000}s Speed</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Pause / Play indicator */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="text-xs font-mono text-slate-400 bg-slate-900/80 hover:bg-slate-800 px-2.5 py-1 rounded-full border border-slate-800 flex items-center gap-1 backdrop-blur-md transition-colors"
            title={isPaused ? "Auto-play resumed" : "Paused on hover / click to toggle"}
          >
            {isPaused ? <Play size={11} className="text-emerald-400" /> : <Pause size={11} className="text-amber-400" />}
            <span className="text-[10px] uppercase font-mono">{isPaused ? 'Paused' : 'Auto'}</span>
          </button>

          <span className="text-xs font-mono text-slate-400 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-800 flex items-center gap-1 backdrop-blur-md">
            <Clock size={12} className="text-indigo-400" />
            <span>{pubDate}</span>
          </span>
        </div>
      </div>

      {/* Main Headline Content Area with transition */}
      <div className="relative z-10 max-w-3xl my-6 transition-all duration-300">
        <a
          href={currentArticle.url}
          target="_blank"
          rel="noopener noreferrer"
          className="group block"
        >
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold leading-tight text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-indigo-400 group-hover:to-cyan-400 transition-all flex items-start gap-2">
            <span className="line-clamp-2">{currentArticle.title}</span>
            <ArrowUpRight size={24} className="shrink-0 mt-1 opacity-0 group-hover:opacity-100 transition-opacity text-cyan-400" />
          </h1>
        </a>

        <p className="text-slate-300/90 text-sm sm:text-base leading-relaxed line-clamp-2 mb-6 font-medium max-w-2xl">
          {currentArticle.body}
        </p>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <a
              href={currentArticle.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-semibold text-xs sm:text-sm hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-500/25 flex items-center gap-2 active:scale-95"
            >
              <span>Read Full Intel</span>
              <ExternalLink size={14} />
            </a>

            <div className="px-3.5 py-2 bg-slate-900/90 text-indigo-300 rounded-xl text-xs font-mono border border-slate-800 uppercase">
              {currentArticle.source}
            </div>
          </div>

          {/* Navigation Dots and Arrows */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="p-2 bg-slate-900/90 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-xl border border-slate-800 hover:border-indigo-500 transition-all cursor-pointer active:scale-95"
              title="Previous Headline"
            >
              <ChevronLeft size={16} />
            </button>

            {/* Indicator Dots */}
            <div className="flex items-center gap-1.5 px-2">
              {headlineArticles.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrentIndex(idx);
                    setProgress(0);
                  }}
                  className={`h-2 rounded-full transition-all cursor-pointer ${
                    idx === currentIndex
                      ? 'w-6 bg-cyan-400 shadow-md shadow-cyan-400/50'
                      : 'w-2 bg-slate-700 hover:bg-slate-500'
                  }`}
                  title={`Go to headline ${idx + 1}`}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              className="p-2 bg-slate-900/90 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-xl border border-slate-800 hover:border-indigo-500 transition-all cursor-pointer active:scale-95"
              title="Next Headline"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


