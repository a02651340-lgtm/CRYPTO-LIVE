import React, { useEffect, useState } from 'react';
import { CryptoTicker } from '../types';
import { RefreshCw, Activity, Zap } from 'lucide-react';
import { fetchLiveCryptoPrices } from '../services/cryptoService';

interface LiveTickerProps {
  setLiveStatus: (status: 'online' | 'connecting' | 'error') => void;
}

const INITIAL_FALLBACK: CryptoTicker[] = [
  { symbol: 'BTCUSDT', lastPrice: '63159.83', priceChangePercent: '-3.11' },
  { symbol: 'ETHUSDT', lastPrice: '1875.52', priceChangePercent: '-3.63' },
  { symbol: 'BNBUSDT', lastPrice: '564.84', priceChangePercent: '-1.45' },
  { symbol: 'SOLUSDT', lastPrice: '73.28', priceChangePercent: '-4.26' },
  { symbol: 'ADAUSDT', lastPrice: '0.1549', priceChangePercent: '-5.98' },
  { symbol: 'XRPUSDT', lastPrice: '1.0581', priceChangePercent: '-4.36' },
  { symbol: 'DOGEUSDT', lastPrice: '0.0701', priceChangePercent: '-3.42' },
  { symbol: 'LINKUSDT', lastPrice: '8.292', priceChangePercent: '-6.26' },
  { symbol: 'AVAXUSDT', lastPrice: '6.407', priceChangePercent: '-4.27' },
];

export const LiveTicker: React.FC<LiveTickerProps> = ({ setLiveStatus }) => {
  const [tickers, setTickers] = useState<CryptoTicker[]>(INITIAL_FALLBACK);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [flashTick, setFlashTick] = useState<boolean>(false);

  const fetchPrices = async () => {
    setIsRefreshing(true);
    setLiveStatus('connecting');
    try {
      const data = await fetchLiveCryptoPrices();
      if (data && data.length > 0) {
        setTickers(data);
        setLiveStatus('online');
        setLastUpdated(new Date());
        setFlashTick(true);
        setTimeout(() => setFlashTick(false), 800);
      } else {
        setLiveStatus('online');
      }
    } catch (err) {
      console.warn('LiveTicker error:', err);
      setLiveStatus('online');
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchPrices();
    // Auto update every 5 seconds as requested by user
    const interval = setInterval(fetchPrices, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="ticker-section" className="mt-[70px] bg-slate-950/90 border-b border-slate-800/80 overflow-hidden flex items-center h-12 relative z-30 select-none">
      <div className="bg-indigo-600 text-white px-3.5 font-mono font-bold text-[11px] uppercase tracking-wider h-full flex items-center gap-2 shrink-0 z-20 shadow-md">
        <Activity size={14} className="animate-pulse text-cyan-300" />
        <span className="hidden sm:inline">LIVE FEED</span>
        <span className="bg-indigo-800/90 px-1.5 py-0.5 rounded text-[10px] font-mono text-cyan-300 border border-indigo-400/40">
          5s AUTO
        </span>
      </div>

      <div className="flex-1 overflow-hidden relative flex items-center">
        <div className="animate-ticker hover:[animation-play-state:paused] flex items-center gap-4 py-1">
          {[...tickers, ...tickers, ...tickers].map((item, idx) => {
            const price = parseFloat(item.lastPrice).toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 4,
            });
            const percent = parseFloat(item.priceChangePercent);
            const isUp = percent >= 0;

            return (
              <div
                key={`${item.symbol}-${idx}`}
                className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border font-mono text-xs transition-all cursor-pointer ${
                  flashTick
                    ? 'bg-indigo-900/60 border-indigo-400'
                    : 'bg-slate-900 border-slate-800 hover:border-indigo-500/50'
                }`}
              >
                <span className="font-bold text-slate-300">{item.symbol}</span>
                <span className="text-white font-medium">${price}</span>
                <span className={`font-bold ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {isUp ? '+' : ''}
                  {percent.toFixed(2)}%
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="hidden lg:flex items-center gap-1.5 px-3 h-full bg-slate-900/80 border-l border-slate-800 text-[10px] font-mono text-slate-400 shrink-0">
        <Zap size={12} className="text-amber-400" />
        <span>Updated: {lastUpdated.toLocaleTimeString()}</span>
      </div>

      <button
        onClick={fetchPrices}
        disabled={isRefreshing}
        className="px-3 h-full bg-slate-900 text-slate-400 hover:text-indigo-400 border-l border-slate-800 z-20 flex items-center justify-center transition-colors shrink-0"
        title={`Updated: ${lastUpdated.toLocaleTimeString()}. Auto-refreshing every 5 seconds.`}
      >
        <RefreshCw size={14} className={isRefreshing ? 'animate-spin text-indigo-400' : ''} />
      </button>
    </section>
  );
};


