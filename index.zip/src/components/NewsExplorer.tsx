import React, { useState } from 'react';
import { NewsArticle } from '../types';
import { ExternalLink, Search, Clock, ShieldAlert, Sparkles, Filter } from 'lucide-react';

interface NewsExplorerProps {
  articles: NewsArticle[];
  loading: boolean;
}

export const NewsExplorer: React.FC<NewsExplorerProps> = ({ articles, loading }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSource, setSelectedSource] = useState('ALL');

  // Unique sources list for quick filter
  const sources = ['ALL', ...Array.from(new Set(articles.map((a) => a.source.toUpperCase())))].slice(0, 7);

  const filtered = articles.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.body.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.source.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSource = selectedSource === 'ALL' || item.source.toUpperCase() === selectedSource;

    return matchesSearch && matchesSource;
  });

  return (
    <div id="news-section" className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md shadow-xl h-full flex flex-col justify-between">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="text-indigo-400 font-mono text-xs uppercase tracking-widest mb-1">Live Intelligence Stream</div>
          <h3 className="font-orbitron font-bold text-xl text-white flex items-center gap-2">
            News <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Explorer</span>
          </h3>
        </div>

        {/* Search input & Filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search news stream..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950/80 border border-slate-800 rounded-full pl-9 pr-4 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-full sm:w-64 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Source pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-none text-xs">
        <span className="text-slate-500 flex items-center gap-1 shrink-0 text-xs font-mono">
          <Filter size={12} className="text-indigo-400" /> Source:
        </span>
        {sources.map((src) => (
          <button
            key={src}
            onClick={() => setSelectedSource(src)}
            className={`px-3.5 py-1.5 rounded-full transition-all shrink-0 font-semibold text-xs ${
              selectedSource === src
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {src}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 font-mono text-[11px] text-indigo-400 tracking-wider uppercase">
              <th className="py-3 px-4 w-28">TIME</th>
              <th className="py-3 px-4 w-32">SOURCE</th>
              <th className="py-3 px-4">INTELLIGENCE SUMMARY</th>
              <th className="py-3 px-4 w-12 text-center">LINK</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-rajdhani text-sm text-slate-300">
            {loading ? (
              <tr>
                <td colSpan={4} className="py-12 text-center text-slate-400 font-mono text-xs">
                  <div className="flex justify-center items-center gap-2">
                    <Sparkles className="animate-spin text-indigo-400" size={18} />
                    <span>Synchronizing telemetry stream...</span>
                  </div>
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-12 text-center text-slate-400 font-mono text-xs">
                  <ShieldAlert className="mx-auto text-amber-400 mb-2" size={24} />
                  No articles found matching query "{searchQuery}".
                </td>
              </tr>
            ) : (
              filtered.map((item) => {
                const pubTime = new Date(item.published_on * 1000).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <tr
                    key={item.id}
                    className="hover:bg-indigo-500/5 transition-colors group"
                  >
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-400 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <Clock size={12} className="text-indigo-400" />
                        <span>{pubTime}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 px-2.5 py-0.5 rounded-full text-[11px] font-mono uppercase">
                        {item.source}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-slate-200 group-hover:text-indigo-300 transition-colors line-clamp-1 block max-w-xl"
                      >
                        {item.title}
                      </a>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-slate-400 hover:text-cyan-400 inline-block p-1"
                        title="Read full article"
                      >
                        <ExternalLink size={15} />
                      </a>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

