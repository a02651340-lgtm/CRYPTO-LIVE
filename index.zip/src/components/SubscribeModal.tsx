import React, { useState } from 'react';
import { SubscriberFormData } from '../types';
import { X, Send, ShieldCheck, Sparkles, User, Mail, Phone, Hash, Award } from 'lucide-react';

interface SubscribeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (name: string) => void;
}

export const SubscribeModal: React.FC<SubscribeModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [formData, setFormData] = useState<SubscriberFormData>({
    fullName: '',
    age: '',
    phone: '',
    email: '',
    experience: '',
  });

  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const envUrl = (import.meta as unknown as { env?: { VITE_GOOGLE_SHEET_WEBHOOK_URL?: string } }).env?.VITE_GOOGLE_SHEET_WEBHOOK_URL;

    const webhookUrl =
      localStorage.getItem('google_sheet_webhook_url') ||
      envUrl ||
      'https://script.google.com/macros/s/AKfycbxNO9OWqpODFPZet3ncVg-VCPGE8WYLP_QuzIhcrcKw9kh9IEJ83gw_ov1HDe2ATkYcuw/exec';

    try {
      if (webhookUrl) {
        // Send JSON payload (Google Apps Script handles text/plain or application/json in doPost e.postData.contents)
        const payload = JSON.stringify({
          timestamp: new Date().toISOString(),
          fullName: formData.fullName,
          age: formData.age,
          phone: formData.phone,
          email: formData.email,
          experience: formData.experience,
        });

        await fetch(webhookUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: payload,
        }).catch((err) => console.warn('Google Sheet JSON submit attempt:', err));

        // Form-encoded fallback for Apps Scripts expecting e.parameter
        const formParams = new URLSearchParams();
        formParams.append('timestamp', new Date().toISOString());
        formParams.append('fullName', formData.fullName);
        formParams.append('age', formData.age);
        formParams.append('phone', formData.phone);
        formParams.append('email', formData.email);
        formParams.append('experience', formData.experience);

        await fetch(webhookUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: formParams.toString(),
        }).catch((err) => console.warn('Google Sheet Form submit attempt:', err));
      } else {
        await new Promise((res) => setTimeout(res, 800));
      }

      // Trigger success alert
      onSuccess(formData.fullName || 'Subscriber');

      // Reset form
      setFormData({
        fullName: '',
        age: '',
        phone: '',
        email: '',
        experience: '',
      });

      onClose();
    } catch (err) {
      console.error('Submission error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[5000] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 shadow-2xl rounded-3xl w-full max-w-lg p-6 sm:p-8 relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-white p-2 rounded-full hover:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X size={20} />
        </button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-mono mb-3">
            <Sparkles size={14} />
            <span>VIP TERMINAL ACCESS</span>
          </div>

          <h3 className="font-orbitron font-bold text-2xl text-white tracking-wide">
            Subscribe <span className="text-indigo-400">Live</span>
          </h3>

          <p className="text-xs text-slate-400 mt-2 max-w-md mx-auto">
            Gain priority access to market intelligence feeds, real-time alerts, and breaking crypto news.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              Full Name
            </label>
            <div className="relative">
              <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                required
                placeholder="e.g. Satoshi Nakamoto"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
                Age
              </label>
              <div className="relative">
                <Hash size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="number"
                  required
                  min="1"
                  max="120"
                  placeholder="e.g. 28"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
                Worldwide Phone
              </label>
              <div className="relative">
                <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="tel"
                  required
                  placeholder="+1 (555) 019-2834"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                required
                placeholder="satoshi@bitcoin.org"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              Crypto Experience Level
            </label>
            <div className="relative">
              <Award size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <select
                required
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-indigo-500 transition-all"
              >
                <option value="" disabled>Select your classification</option>
                <option value="Beginner">Beginner - Exploring ecosystem utilities</option>
                <option value="Intermediate">Intermediate - Active transactor</option>
                <option value="Professional">Professional - High volume algorithm designer</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full font-semibold text-sm text-white py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-[0.98] transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 cursor-pointer mt-3"
          >
            {submitting ? (
              <>
                <Sparkles className="animate-spin text-indigo-200" size={18} />
                <span>Syncing Database...</span>
              </>
            ) : (
              <>
                <Send size={16} />
                <span>Join Now</span>
              </>
            )}
          </button>

          <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono text-slate-500 pt-2">
            <ShieldCheck size={14} className="text-indigo-400" />
            <span>Encrypted channel transmission protocol</span>
          </div>
        </form>
      </div>
    </div>
  );
};


