import React, { useEffect, useState } from 'react';

interface IntroOverlayProps {
  onComplete: () => void;
}

export const IntroOverlay: React.FC<IntroOverlayProps> = ({ onComplete }) => {
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setFading(true);
    }, 2800);

    const timer2 = setTimeout(() => {
      onComplete();
    }, 3600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-[10000] bg-[#02040a] flex flex-col justify-center items-center transition-opacity duration-700 ease-in-out ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="relative text-center px-4">
        <h1 className="font-orbitron font-black text-4xl sm:text-6xl tracking-[8px] text-transparent bg-clip-text bg-gradient-to-r from-[#00ffcc] via-white to-[#8a2be2] drop-shadow-[0_0_25px_rgba(0,255,204,0.6)]">
          CRYPTO LIVE
        </h1>
        <p className="font-orbitron text-xs sm:text-sm text-[#f3ba2f] tracking-[4px] mt-4 uppercase animate-pulse">
          Real-Time Market Cybernetics
        </p>

        <div className="w-48 sm:w-64 h-[2px] bg-white/10 mx-auto mt-8 relative overflow-hidden rounded-full">
          <div className="absolute top-0 left-0 h-full bg-[#00ffcc] shadow-[0_0_12px_#00ffcc] animate-progress" />
        </div>

        <div className="mt-6 flex items-center justify-center gap-2 text-[10px] font-orbitron text-slate-500 uppercase tracking-widest">
          <span className="w-2 h-2 rounded-full bg-[#00ffcc] animate-ping" />
          <span>Connecting Telemetry Nodes...</span>
        </div>
      </div>
    </div>
  );
};
