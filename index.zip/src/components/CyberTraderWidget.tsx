import React from 'react';

interface CyberTraderWidgetProps {
  openSubscribeModal: () => void;
}

export const CyberTraderWidget: React.FC<CyberTraderWidgetProps> = ({ openSubscribeModal }) => {
  return (
    <div
      onClick={openSubscribeModal}
      className="fixed bottom-[30%] right-6 w-24 h-24 sm:w-28 sm:h-28 z-[999] cursor-pointer group hover:scale-110 hover:-rotate-6 transition-all duration-300 select-none"
      title="Click to subscribe to Crypto Live alerts"
    >
      {/* Floating Chat Bubble */}
      <div className="absolute -top-12 -right-2 bg-indigo-600 text-white font-mono font-bold text-[11px] px-3 py-1.5 rounded-full shadow-xl border border-indigo-400 animate-bounce-gentle whitespace-nowrap">
        <span>SUBSCRIBE!</span>
        <div className="absolute -bottom-1.5 right-6 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-indigo-600" />
      </div>

      {/* SVG Trader Character */}
      <svg
        className="w-full h-full drop-shadow-[0_0_20px_rgba(99,102,241,0.5)]"
        viewBox="0 0 100 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="screenGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6366f1" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>

        {/* Chair Back */}
        <path d="M25,80 L25,45 L35,45 L35,80 Z" fill="#0f172a" />
        <rect x="22" y="40" width="16" height="6" rx="2" fill="#818cf8" opacity="0.8" />

        {/* Head & Headset */}
        <circle cx="50" cy="35" r="12" fill="#fdd3a6" />
        <path d="M38,35 C38,20 62,20 62,35" fill="none" stroke="#0f172a" strokeWidth="4" />
        <circle cx="38" cy="35" r="3.5" fill="#818cf8" />
        <circle cx="62" cy="35" r="3.5" fill="#818cf8" />

        {/* Cyber Goggles */}
        <rect x="44" y="31" width="14" height="4" rx="1" fill="#22d3ee" />
        <line x1="40" y1="33" x2="60" y2="33" stroke="#22d3ee" strokeWidth="1.5" />

        {/* Body / Jacket */}
        <path d="M32,80 L40,48 L60,48 L68,80 Z" fill="#0f172a" />
        <path d="M42,48 L50,65 L58,48" fill="none" stroke="#6366f1" strokeWidth="3" />

        {/* Laptop */}
        <rect
          x="55"
          y="65"
          width="28"
          height="18"
          rx="2"
          transform="rotate(-10 69 74)"
          fill="#1e293b"
          stroke="#818cf8"
          strokeWidth="1"
        />
        <polygon points="52,80 82,75 88,82 54,85" fill="#0f172a" />
        <rect
          x="58"
          y="67"
          width="22"
          height="14"
          transform="rotate(-10 69 74)"
          fill="url(#screenGlow)"
          opacity="0.9"
        />

        {/* Hands Typing */}
        <circle cx="54" cy="75" r="2.5" fill="#fdd3a6" />
        <circle cx="62" cy="73" r="2.5" fill="#fdd3a6" />
      </svg>
    </div>
  );
};

