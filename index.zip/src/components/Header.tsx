import React from 'react';
import { Menu, X, Zap, Bell, Shield } from 'lucide-react';

interface HeaderProps {
  isMenuOpen: boolean;
  toggleMenu: () => void;
  openSubscribeModal: () => void;
  liveStatus: 'online' | 'connecting' | 'error';
}

export const Header: React.FC<HeaderProps> = ({
  isMenuOpen,
  toggleMenu,
  openSubscribeModal,
  liveStatus,
}) => {
  return (
    <header className="fixed top-0 left-0 w-full h-[70px] bg-slate-950/85 backdrop-blur-md border-b border-slate-800 z-[1000] flex justify-between items-center px-4 md:px-10">
      <div className="flex items-center gap-4">
        <button
          onClick={toggleMenu}
          className="p-2 text-indigo-400 hover:bg-indigo-500/10 rounded-xl transition-colors border border-slate-800 focus:outline-none"
          aria-label="Toggle navigation drawer"
        >
          {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        <a href="#" className="flex items-center gap-2 font-orbitron font-bold text-xl tracking-tight text-white">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-white text-sm shadow-md shadow-indigo-500/20">
            C
          </div>
          <span>CRYPTO<span className="text-indigo-400">LIVE</span></span>
        </a>

        <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300">
          <span
            className={`w-2 h-2 rounded-full ${
              liveStatus === 'online'
                ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                : liveStatus === 'connecting'
                ? 'bg-amber-400 animate-pulse'
                : 'bg-rose-500'
            }`}
          />
          <span className="uppercase tracking-wider">
            {liveStatus === 'online' ? 'Global Ready' : liveStatus === 'connecting' ? 'Syncing' : 'Offline'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={openSubscribeModal}
          className="hidden md:flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-indigo-400 hover:border-slate-700 transition-all"
        >
          <Bell size={14} className="text-indigo-400" />
          <span>Alerts</span>
        </button>

        <button
          onClick={openSubscribeModal}
          className="px-5 py-2 bg-white text-slate-950 rounded-full text-xs font-bold hover:bg-indigo-50 transition-all shadow-md shadow-white/10 hover:shadow-indigo-500/20 flex items-center gap-1.5 cursor-pointer"
        >
          <Zap size={14} className="fill-slate-950" />
          <span>Launch Console</span>
        </button>
      </div>
    </header>
  );
};

