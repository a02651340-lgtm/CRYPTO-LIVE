import React, { useState } from 'react';
import { ArrowLeftRight, Calculator, DollarSign, Sparkles } from 'lucide-react';

interface CryptoConverterProps {
  btcPrice?: number;
  ethPrice?: number;
  solPrice?: number;
  bnbPrice?: number;
}

export const CryptoConverter: React.FC<CryptoConverterProps> = ({
  btcPrice = 63159.83,
  ethPrice = 1875.52,
  solPrice = 73.28,
  bnbPrice = 564.84,
}) => {
  const [amount, setAmount] = useState<string>('1');
  const [cryptoSymbol, setCryptoSymbol] = useState<string>('BTC');

  const prices: Record<string, number> = {
    BTC: btcPrice,
    ETH: ethPrice,
    SOL: solPrice,
    BNB: bnbPrice,
  };

  const numAmount = parseFloat(amount) || 0;
  const currentPrice = prices[cryptoSymbol] || btcPrice;
  const usdTotal = (numAmount * currentPrice).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 backdrop-blur-md shadow-xl flex flex-col justify-between hover:border-indigo-500/30 transition-all">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-slate-400 text-[11px] font-mono uppercase tracking-wider">Instant Utility</p>
          <h3 className="font-orbitron font-bold text-lg text-white flex items-center gap-2">
            Crypto <span className="text-indigo-400">Calculator</span>
          </h3>
        </div>
        <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
          <Calculator size={18} />
        </div>
      </div>

      <div className="space-y-3 my-2">
        <div>
          <label className="block text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
            Amount & Token
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              min="0"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3.5 py-2 text-sm font-mono text-white focus:outline-none focus:border-indigo-500 transition-all"
              placeholder="1.0"
            />
            <select
              value={cryptoSymbol}
              onChange={(e) => setCryptoSymbol(e.target.value)}
              className="bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-indigo-300 font-bold focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="BTC">BTC</option>
              <option value="ETH">ETH</option>
              <option value="SOL">SOL</option>
              <option value="BNB">BNB</option>
            </select>
          </div>
        </div>

        <div className="flex justify-center my-1">
          <div className="p-1.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
            <ArrowLeftRight size={14} className="rotate-90 sm:rotate-0 text-indigo-400" />
          </div>
        </div>

        <div className="bg-slate-950/90 border border-indigo-500/30 rounded-2xl p-4 text-center">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            Estimated Value (USD)
          </span>
          <div className="flex items-center justify-center gap-1 text-2xl font-bold font-mono text-emerald-400">
            <DollarSign size={20} className="shrink-0 text-emerald-500" />
            <span>{usdTotal}</span>
          </div>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">
            1 {cryptoSymbol} ≈ ${currentPrice.toLocaleString()} USD
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 pt-2 text-[10px] font-mono text-slate-500 justify-center">
        <Sparkles size={12} className="text-indigo-400" />
        <span>Real-time Binance rate valuation</span>
      </div>
    </div>
  );
};
