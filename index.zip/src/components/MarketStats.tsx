import React from 'react';
import { PieChart, Gauge, Fuel, BarChart3, Activity } from 'lucide-react';

export const MarketStats: React.FC = () => {
  const stats = [
    {
      label: 'BTC Dominance',
      value: '55.82%',
      change: '+0.4%',
      icon: PieChart,
      color: 'text-indigo-400',
    },
    {
      label: 'Total Volume (24h)',
      value: '$84.15B',
      change: '+12.3%',
      icon: BarChart3,
      color: 'text-cyan-400',
    },
    {
      label: 'ETH Gas Price',
      value: '28 Gwei',
      change: 'Optimal',
      icon: Fuel,
      color: 'text-emerald-400',
    },
    {
      label: 'Fear & Greed',
      value: '74 (Greed)',
      change: 'Bullish',
      icon: Gauge,
      color: 'text-amber-400',
    },
  ];

  return (
    <div id="about-section" className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 backdrop-blur-md shadow-xl">
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="text-slate-400 text-[11px] font-mono uppercase tracking-wider">Network Telemetry</p>
          <h3 className="font-orbitron font-bold text-lg text-white flex items-center gap-2">
            Market <span className="text-indigo-400">Statistics</span>
          </h3>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-mono text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>Active</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div
              key={idx}
              className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3.5 text-center hover:border-indigo-500/40 transition-all"
            >
              <div className="flex items-center justify-center gap-1.5 text-slate-400 text-[10px] font-mono uppercase mb-1.5">
                <Icon size={13} className="text-indigo-400" />
                <span>{stat.label}</span>
              </div>
              <p className={`font-mono font-bold text-base sm:text-lg ${stat.color}`}>
                {stat.value}
              </p>
              <span className="inline-block mt-1.5 text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded-full border border-slate-800">
                {stat.change}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

