import React from 'react';
import { LayoutDashboard, Newspaper, Activity, TrendingUp, Info, Mail, Sparkles, ChevronRight } from 'lucide-react';

interface NavDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  openSubscribeModal: () => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
}

export const NavDrawer: React.FC<NavDrawerProps> = ({
  isOpen,
  onClose,
  openSubscribeModal,
  activeSection,
  setActiveSection,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'news', label: 'Latest News', icon: Newspaper },
    { id: 'insights', label: 'Market Insights', icon: TrendingUp },
    { id: 'ticker', label: 'Binance Feed', icon: Activity },
    { id: 'about', label: 'About System', icon: Info },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    onClose();
    const elem = document.getElementById(`${id}-section`);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[1999] transition-opacity"
        />
      )}

      {/* Drawer */}
      <nav
        className={`fixed top-0 left-0 w-80 h-full bg-slate-950 border-r border-slate-800 z-[2000] transition-transform duration-300 ease-out flex flex-col justify-between p-6 pt-24 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div>
          <div className="mb-8 px-2">
            <span className="text-indigo-400 font-mono text-xs uppercase tracking-widest">Navigation Protocol</span>
            <h2 className="font-orbitron font-bold text-lg text-white mt-1">MAIN TERMINAL</h2>
          </div>

          <ul className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl font-semibold text-sm transition-all group ${
                      isActive
                        ? 'bg-indigo-600/15 border border-indigo-500/40 text-indigo-300 shadow-md'
                        : 'text-slate-300 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon size={18} className={isActive ? 'text-indigo-400' : 'text-slate-400 group-hover:text-indigo-400'} />
                      <span>{item.label}</span>
                    </div>
                    <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity text-indigo-400" />
                  </button>
                </li>
              );
            })}

            <li>
              <button
                onClick={() => {
                  onClose();
                  openSubscribeModal();
                }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-2xl font-semibold text-sm text-amber-300 hover:bg-amber-500/10 border border-amber-500/30 transition-all mt-4"
              >
                <div className="flex items-center gap-3">
                  <Mail size={18} className="text-amber-400" />
                  <span>VIP Subscription</span>
                </div>
                <Sparkles size={16} className="text-amber-400" />
              </button>
            </li>
          </ul>
        </div>

        <div className="border-t border-slate-800 pt-6 text-center text-xs font-mono text-slate-500 space-y-2">
          <div className="flex items-center justify-center gap-2 text-[10px] text-indigo-400">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
            <span>ENCRYPTED DATAFEED ACTIVE</span>
          </div>
          <p>© {new Date().getFullYear()} CRYPTO LIVE INC.</p>
        </div>
      </nav>
    </>
  );
};

