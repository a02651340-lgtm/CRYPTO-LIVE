import React, { useEffect, useState } from 'react';
import { CryptoTicker } from '../types';
import { TrendingUp, ArrowUpRight, ArrowDownRight, RefreshCw, Zap } from 'lucide-react';
import { fetchLiveCryptoPrices } from '../services/cryptoService';

interface MarketInsightsProps {
  openSubscribeModal: () => void;
}

const DEFAULT_INSIGHTS: CryptoTicker[] = [
  { symbol: 'BTCUSDT', lastPrice: '63159.83', priceChangePercent: '-3.11' },
  { symbol: 'ETHUSDT', lastPrice: '1875.52', priceChangePercent: '-3.63' },
  { symbol: 'BNBUSDT', lastPrice: '564.84', priceChangePercent: '-1.45' },
  { symbol: 'SOLUSDT', lastPrice: '73.28', priceChangePercent: '-4.26' },
];

export const MarketInsights: React.FC<MarketInsightsProps> = ({ openSubscribeModal }) => {
  const [items, setItems] = useState<CryptoTicker[]>(DEFAULT_INSIGHTS);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await fetchLiveCryptoPrices();
      if (data && data.length > 0) {
        const targets = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT'];
        const filtered = data.filter((d) => targets.includes(d.symbol));
        if (filtered.length > 0) {
          setItems(filtered);
          setLastUpdated(new Date());
        }
      }
    } catch (e) {
      console.warn('MarketInsights error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // Auto update every 5 seconds as requested by user
    const timer = setInterval(loadData, 5000);
    return () => clearInterval(timer);
  }, []);

  const getCleanName = (sym: string) => {
    switch (sym) {
      case 'BTCUSDT':
        return { name: 'Bitcoin', tag: 'BTC' };
      case 'ETHUSDT':
        return { name: 'Ethereum', tag: 'ETH' };
      case 'BNBUSDT':
        return { name: 'BNB Coin', tag: 'BNB' };
      case 'SOLUSDT':
        return { name: 'Solana', tag: 'SOL' };
      default:
        return { name: sym.replace('USDT', ''), tag: sym.replace('USDT', '') };
    }
  };

  return (
    <div id="insights-section" className="bento-card-indigo rounded-3xl p-6 sm:p-7 shadow-xl relative overflow-hidden h-full flex flex-col justify-between">
      {/* Glow Effect */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/20 blur-[60px] rounded-full pointer-events-none" />

      {/* Header Metric */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500/20 rounded-xl border border-indigo-500/40 flex items-center justify-center">
            <Zap size={20} className="text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="text-indigo-200/70 text-xs font-mono uppercase tracking-wider">Live Prices</p>
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.5 rounded text-[10px] font-mono animate-pulse">
                5s Live
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-orbitron">
              Core Assets
            </h3>
          </div>
        </div>
        <button
          onClick={loadData}
          className="text-slate-400 hover:text-indigo-300 p-2 rounded-lg hover:bg-indigo-500/10 transition-colors"
          title={`Last updated ${lastUpdated.toLocaleTimeString()}. Click to force refresh.`}
        >
          <RefreshCw size={14} className={loading ? 'animate-spin text-indigo-400' : ''} />
        </button>
      </div>

      {/* Throughput Bar Chart Visualizer */}
      <div className="flex items-end gap-1.5 h-10 my-5 px-1">
        <div className="flex-grow bg-indigo-400/20 h-[35%] rounded-sm animate-pulse" />
        <div className="flex-grow bg-indigo-400/30 h-[65%] rounded-sm" />
        <div className="flex-grow bg-indigo-400/20 h-[45%] rounded-sm" />
        <div className="flex-grow bg-indigo-400/40 h-[80%] rounded-sm" />
        <div className="flex-grow bg-indigo-400 h-[100%] rounded-sm shadow-[0_0_8px_#818cf8]" />
        <div className="flex-grow bg-indigo-400/70 h-[75%] rounded-sm" />
        <div className="flex-grow bg-indigo-400/30 h-[50%] rounded-sm" />
        <div className="flex-grow bg-cyan-400/80 h-[90%] rounded-sm shadow-[0_0_8px_#22d3ee]" />
      </div>

      {/* Asset Price List */}
      <div className="space-y-2.5">
        {items.map((item) => {
          const { name, tag } = getCleanName(item.symbol);
          const price = parseFloat(item.lastPrice).toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          });
          const pct = parseFloat(item.priceChangePercent);
          const isUp = pct >= 0;

          return (
            <div
              key={item.symbol}
              onClick={openSubscribeModal}
              className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-indigo-500/50 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-900/40 border border-indigo-500/40 flex items-center justify-center font-mono font-bold text-xs text-indigo-300">
                  {tag}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white group-hover:text-indigo-300 transition-colors">
                    {name}
                  </h4>
                  <p className="text-[10px] text-slate-400 font-mono">{item.symbol}</p>
                </div>
              </div>

              <div className="text-right font-mono">
                <p className="font-bold text-sm text-white">${price}</p>
                <p className={`text-xs font-semibold flex items-center justify-end gap-0.5 ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {isUp ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {isUp ? '+' : ''}
                  {pct.toFixed(2)}%
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


